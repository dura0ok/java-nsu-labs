package fit.nsu.labs;

import fit.nsu.labs.components.CarBody;
import fit.nsu.labs.components.CarComponentFactory;
import fit.nsu.labs.components.CarEngine;
import fit.nsu.labs.storage.RamStorage;
import fit.nsu.labs.tasks.BuildCar;
import io.github.cdimascio.dotenv.Dotenv;

import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) {
        try{
            Dotenv dotenv = Dotenv.load();
            var carBodyFactory = new CarComponentFactory<>(
                    CarBody.class,
                    new RamStorage(Integer.parseInt(dotenv.get("STORAGE_BODY_SIZE")))
            );

            var carEngineFactory = new CarComponentFactory<>(
                    CarEngine.class,
                    new RamStorage(Integer.parseInt(dotenv.get("STORAGE_ENGINE_SIZE")))
            );

            var workers_count = Integer.parseInt(dotenv.get("WORKERS"));
            var executor = Executors.newFixedThreadPool(workers_count);
            for(int i = 0; i < workers_count; i++){
                executor.execute(new BuildCar(carBodyFactory, carEngineFactory));
            }

            executor.shutdownNow();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}