package fit.nsu.labs.components;

public class CarBody extends CarComponent {
}
