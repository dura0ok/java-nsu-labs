package fit.nsu.labs.components;

public class CarEngine extends CarComponent {
}
